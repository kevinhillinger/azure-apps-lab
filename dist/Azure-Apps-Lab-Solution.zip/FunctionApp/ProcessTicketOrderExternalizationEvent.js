module.exports = function (context, orderItem) {
    context.log('Ticket Order received: ', orderItem);

    context.bindings.orderDocument = orderItem;
    context.done();
};